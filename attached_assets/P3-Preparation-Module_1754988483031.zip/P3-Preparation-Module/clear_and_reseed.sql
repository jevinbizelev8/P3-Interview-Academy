-- Clear existing data to reseed with expanded question bank
DELETE FROM responses;
DELETE FROM questions;