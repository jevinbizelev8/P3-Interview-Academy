﻿import * as client from "openid-client";
import { Strategy, type VerifyFunction } from "openid-client/passport";
import passport from "passport";
import session from "express-session";
import type { Express, RequestHandler } from "express";
import memoize from "memoizee";
import { createSessionStore } from "./session-store";
import { storage } from "./storage";

if (!process.env.REPLIT_DOMAINS) {
  throw new Error("Environment variable REPLIT_DOMAINS not provided");
}

const getOidcConfig = memoize(
  async () => {
    return await client.discovery(
      new URL(process.env.ISSUER_URL ?? "https://replit.com/oidc"),
      process.env.REPL_ID!
    );
  },
  { maxAge: 3600 * 1000 }
);

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const sessionStore = createSessionStore({
    createTableIfMissing: false,
    ttl: Math.floor(sessionTtl / 1000),
  });
  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: sessionTtl,
      sameSite: 'lax',
    },
  });
}

function updateUserSession(
  user: any,
  tokens: client.TokenEndpointResponse & client.TokenEndpointResponseHelpers
) {
  user.claims = tokens.claims();
  user.access_token = tokens.access_token;
  user.refresh_token = tokens.refresh_token;
  user.expires_at = user.claims?.exp;
}

async function upsertUser(claims: any) {
  await storage.upsertUser({
    id: claims["sub"],
    email: claims["email"],
    firstName: claims["first_name"],
    lastName: claims["last_name"],
    profileImageUrl: claims["profile_image_url"],
    role: "user",
  });
}

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());
  app.use(passport.initialize());
  app.use(passport.session());

  const config = await getOidcConfig();

  const verify: VerifyFunction = async (
    tokens: client.TokenEndpointResponse & client.TokenEndpointResponseHelpers,
    verified: passport.AuthenticateCallback
  ) => {
    try {
      const claims = tokens.claims();
      if (!claims) {
        return verified(new Error("No claims found in token"));
      }
      
      const user = {
        id: String(claims["sub"] || ""),
        email: String(claims["email"] || ""),
        firstName: String(claims["first_name"] || ""),
        lastName: String(claims["last_name"] || ""),
        role: "user" as const
      };
      
      updateUserSession(user as any, tokens);
      await upsertUser(claims);
      verified(null, user);
    } catch (error) {
      console.error("Auth verification error:", error);
      verified(error);
    }
  };

  for (const domain of process.env.REPLIT_DOMAINS!.split(",")) {
    const callbackURL = `https://${domain}/api/callback`;
    console.log("Registering OAuth strategy:", {
      domain,
      callbackURL,
      clientId: process.env.REPL_ID
    });
    
    const strategy = new Strategy(
      {
        name: `replitauth:${domain}`,
        config,
        scope: "openid email profile offline_access",
        callbackURL,
      },
      verify,
    );
    passport.use(strategy);
  }

  passport.serializeUser((user: Express.User, cb) => cb(null, user));
  passport.deserializeUser((user: Express.User, cb) => cb(null, user));

  app.get("/api/login", (req, res, next) => {
    console.log("Login attempt:", {
      sessionID: req.sessionID,
      user: req.user,
      isAuthenticated: req.isAuthenticated?.()
    });
    
    // Use the first available domain strategy
    const domains = process.env.REPLIT_DOMAINS!.split(",");
    const strategyName = `replitauth:${domains[0]}`;
    
    console.log("Using auth strategy:", strategyName);
    
    passport.authenticate(strategyName, {
      prompt: "login consent", 
      scope: ["openid", "email", "profile", "offline_access"],
    })(req, res, next);
  });

  app.get("/api/callback", (req, res, next) => {
    console.log("OAuth callback received:", {
      query: req.query,
      headers: req.headers,
      sessionID: req.sessionID
    });
    
    // Use the first available domain strategy
    const domains = process.env.REPLIT_DOMAINS!.split(",");
    const strategyName = `replitauth:${domains[0]}`;
    
    passport.authenticate(strategyName, {
      successReturnToOrRedirect: "/dashboard",
      failureRedirect: "/?error=auth_failed",
    })(req, res, (err: any) => {
      if (err) {
        console.error("Authentication callback error:", err);
        return res.redirect("/?error=auth_failed");
      }
      next();
    });
  });

  app.get("/api/logout", (req, res) => {
    req.logout(() => {
      // Build proper redirect URI with port if needed
      const baseUrl = req.get('host')?.includes('localhost') 
        ? `${req.protocol}://${req.get('host')}`
        : `${req.protocol}://${req.hostname}`;
      
      res.redirect(
        client.buildEndSessionUrl(config, {
          client_id: process.env.REPL_ID!,
          post_logout_redirect_uri: baseUrl,
        }).href
      );
    });
  });
}

export const isAuthenticated: RequestHandler = async (req, res, next) => {
  const user = req.user as any;

  if (!req.isAuthenticated() || !user.expires_at) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const now = Math.floor(Date.now() / 1000);
  if (now <= user.expires_at) {
    return next();
  }

  const refreshToken = user.refresh_token;
  if (!refreshToken) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }

  try {
    const config = await getOidcConfig();
    const tokenResponse = await client.refreshTokenGrant(config, refreshToken);
    updateUserSession(user, tokenResponse);
    return next();
  } catch (error) {
    res.status(401).json({ message: "Unauthorized" });
    return;
  }
};

