import { sealionService } from './sealion';
import type { InterviewMessage, InterviewSession, AiEvaluationResult } from '@shared/schema';
import { SUPPORTED_LANGUAGES } from '@shared/schema';

// Language-specific fallback messages
const LANGUAGE_FALLBACKS = {
  en: {
    firstQuestion: (jobRole: string, company: string) => 
      `Hello! I'm your AI interviewer for the ${jobRole} position at ${company}. I'll be conducting a comprehensive interview tailored specifically to this role and company. Let's begin with an introduction - please tell me about yourself and why you're interested in this position at ${company}.`,
    followUpGeneric: "That's interesting. Can you tell me more about a specific situation where you demonstrated that skill?",
    finalMessage: (jobRole: string, company: string) =>
      `Thank you for this comprehensive interview! You've provided excellent insights into your experience and approach to the ${jobRole} role at ${company}. I'm now preparing your detailed performance evaluation with personalized feedback and recommendations. This will be available shortly.`
  },
  ms: {
    firstQuestion: (jobRole: string, company: string) => 
      `Selamat datang! Saya penginterview AI untuk jawatan ${jobRole} di ${company}. Saya akan menjalankan temuduga menyeluruh yang disesuaikan khusus untuk peranan dan syarikat ini. Mari kita mulakan dengan pengenalan - sila ceritakan tentang diri anda dan mengapa anda berminat dengan jawatan ini di ${company}.`,
    followUpGeneric: "Itu menarik. Bolehkah anda ceritakan lebih lanjut tentang situasi khusus di mana anda menunjukkan kemahiran tersebut?",
    finalMessage: (jobRole: string, company: string) =>
      `Terima kasih atas temuduga yang menyeluruh ini! Anda telah memberikan pandangan yang sangat baik tentang pengalaman dan pendekatan anda terhadap peranan ${jobRole} di ${company}. Saya sedang menyediakan penilaian prestasi terperinci anda dengan maklum balas dan cadangan yang diperibadikan. Ini akan tersedia tidak lama lagi.`
  },
  id: {
    firstQuestion: (jobRole: string, company: string) => 
      `Halo! Saya pewawancara AI untuk posisi ${jobRole} di ${company}. Saya akan melakukan wawancara komprehensif yang disesuaikan khusus untuk peran dan perusahaan ini. Mari kita mulai dengan perkenalan - tolong ceritakan tentang diri Anda dan mengapa Anda tertarik dengan posisi ini di ${company}.`,
    followUpGeneric: "Itu menarik. Bisakah Anda menceritakan lebih banyak tentang situasi spesifik di mana Anda menunjukkan keterampilan tersebut?",
    finalMessage: (jobRole: string, company: string) =>
      `Terima kasih atas wawancara komprehensif ini! Anda telah memberikan wawasan yang sangat baik tentang pengalaman dan pendekatan Anda terhadap peran ${jobRole} di ${company}. Saya sekarang sedang mempersiapkan evaluasi kinerja detail Anda dengan umpan balik dan rekomendasi yang dipersonalisasi. Ini akan tersedia sebentar lagi.`
  },
  th: {
    firstQuestion: (jobRole: string, company: string) => 
      `สวัสดีครับ! ผมเป็นผู้สัมภาษณ์ AI สำหรับตำแหน่ง ${jobRole} ที่ ${company} ผมจะทำการสัมภาษณ์แบบครอบคลุมที่ปรับแต่งเฉพาะสำหรับตำแหน่งและบริษัทนี้ เริ่มต้นด้วยการแนะนำตัว - กรุณาเล่าเกี่ยวกับตัวคุณและเหตุผลที่คุณสนใจตำแหน่งนี้ที่ ${company}`,
    followUpGeneric: "น่าสนใจมาก คุณช่วยเล่าเพิ่มเติมเกี่ยวกับสถานการณ์เฉพาะที่คุณแสดงให้เห็นทักษะนั้นได้ไหม?",
    finalMessage: (jobRole: string, company: string) =>
      `ขอบคุณสำหรับการสัมภาษณ์ที่ครอบคลุมนี้! คุณได้ให้ข้อมูลเชิงลึกที่ยอดเยี่ยมเกี่ยวกับประสบการณ์และแนวทางของคุณสำหรับตำแหน่ง ${jobRole} ที่ ${company} ตอนนี้ผมกำลังเตรียมการประเมินผลการปฏิบัติงานโดยละเอียดพร้อมข้อเสนอแนะและคำแนะนำที่เป็นส่วนตัว ซึ่งจะพร้อมใช้งานในไม่ช้า`
  },
  vi: {
    firstQuestion: (jobRole: string, company: string) => 
      `Xin chào! Tôi là người phỏng vấn AI cho vị trí ${jobRole} tại ${company}. Tôi sẽ tiến hành một cuộc phỏng vấn toàn diện được thiết kế riêng cho vai trò và công ty này. Hãy bắt đầu bằng việc giới thiệu - vui lòng kể cho tôi nghe về bản thân và lý do bạn quan tâm đến vị trí này tại ${company}.`,
    followUpGeneric: "Thật thú vị. Bạn có thể kể thêm về một tình huống cụ thể mà bạn đã thể hiện kỹ năng đó không?",
    finalMessage: (jobRole: string, company: string) =>
      `Cảm ơn bạn đã tham gia cuộc phỏng vấn toàn diện này! Bạn đã cung cấp những hiểu biết xuất sắc về kinh nghiệm và cách tiếp cận của mình đối với vai trò ${jobRole} tại ${company}. Tôi đang chuẩn bị đánh giá hiệu suất chi tiết của bạn với phản hồi và khuyến nghị được cá nhân hóa. Điều này sẽ có sẵn sớm.`
  },
  fil: {
    firstQuestion: (jobRole: string, company: string) => 
      `Kumusta! Ako ang inyong AI interviewer para sa posisyon ng ${jobRole} sa ${company}. Magsasagawa ako ng komprehensibong interbyu na naka-customize para sa papel at kumpanyang ito. Magsimula tayo sa panimula - pakikwento po tungkol sa inyong sarili at bakit kayo interesado sa posisyong ito sa ${company}.`,
    followUpGeneric: "Nakakainteresa iyon. Maaari ba ninyong ikwento nang higit pa ang tungkol sa isang partikular na sitwasyon kung saan ninyo naipakita ang kasanayang iyon?",
    finalMessage: (jobRole: string, company: string) =>
      `Salamat sa komprehensibong interbyu na ito! Nagbigay kayo ng napakagandang mga insight tungkol sa inyong karanasan at diskarte sa papel ng ${jobRole} sa ${company}. Inihahanda ko na ang inyong detalyadong pagtatasa ng performance na may personalized na feedback at mga rekomendasyon. Magiging available ito maya-maya.`
  },
  my: {
    firstQuestion: (jobRole: string, company: string) => 
      `မင်္ဂလာပါ! ကျွန်တော်သည် ${company} ရှိ ${jobRole} ရာထူးအတွက် AI အင်တာဗျူးယာဖြစ်ပါသည်။ ဤအခန်းကဏ္ဍနှင့် ကုမ္ပဏီအတွက် အထူးပြုလုပ်ထားသော ပြည့်စုံသော အင်တာဗျူးကို လုပ်ဆောင်မည်ဖြစ်ပါသည်။ မိတ်ဆက်ခြင်းဖြင့် စတင်ကြပါစို့ - သင့်အကြောင်းနှင့် ${company} တွင် ဤရာထူးကို အဘယ်ကြောင့် စိတ်ဝင်စားသည်ကို ပြောပြပါ။`,
    followUpGeneric: "စိတ်ဝင်စားဖွယ်ပါပဲ။ သင်သည် ထိုကျွမ်းကျင်မှုကို ပြသခဲ့သည့် တိကျသော အခြေအနေတစ်ခုအကြောင်း နောက်ထပ် ပြောပြနိုင်မလား?",
    finalMessage: (jobRole: string, company: string) =>
      `ဤပြည့်စုံသော အင်တာဗျူးအတွက် ကျေးးဇူးတင်ပါသည်! သင်သည် ${company} ရှိ ${jobRole} အခန်းကဏ္ဍအတွက် သင့်အတွေ့အကြုံနှင့် ချဉ်းကပ်မှုအကြောင်း အလွန်ကောင်းမွန်သော ထိုးထွင်းမြင်ကွင်းများ ပေးခဲ့ပါသည်။ ကျွန်တော်သည် ယခုအခါ သင့်အတွက် ပုဂ္ဂိုလ်ရေးဆိုင်ရာ တုံ့ပြန်ချက်နှင့် အကြံပြုချက်များဖြင့် အသေးစိတ် စွမ်းဆောင်ရည် အကဲဖြတ်ချက်ကို ပြင်ဆင်နေပါသည်။ ယင်းသည် မကြာမီတွင် ရရှိနိုင်မည်ဖြစ်ပါသည်။`
  },
  km: {
    firstQuestion: (jobRole: string, company: string) => 
      `ជំរាបសួរ! ខ្ញុំជាអ្នកសម្ភាសន៍ AI សម្រាប់មុខតំណែង ${jobRole} នៅ ${company}។ ខ្ញុំនឹងធ្វើការសម្ភាសន៍ពេញលេញដែលត្រូវបានរៀបចំជាពិសេសសម្រាប់តួនាទីនិងក្រុមហ៊ុននេះ។ សូមចាប់ផ្តើមជាមួយការណែនាំ - សូមប្រាប់ខ្ញុំអំពីខ្លួនអ្នកនិងហេតុផលដែលអ្នកចាប់អារម្មណ៍នឹងមុខតំណែងនេះនៅ ${company}។`,
    followUpGeneric: "វាគួរឱ្យចាប់អារម្មណ៍។ តើអ្នកអាចប្រាប់ខ្ញុំបន្ថែមអំពីស្ថានភាពជាក់លាក់មួយដែលអ្នកបានបង្ហាញជំនាញនោះបានទេ?",
    finalMessage: (jobRole: string, company: string) =>
      `អរគុណសម្រាប់ការសម្ភាសន៍ពេញលេញនេះ! អ្នកបានផ្តល់នូវយោបល់ដ៏ល្អអំពីបទពិសោធន៍និងវិធីសាស្រ្តរបស់អ្នកចំពោះតួនាទី ${jobRole} នៅ ${company}។ ខ្ញុំកំពុងរៀបចំការវាយតម្លៃដំណើរការលម្អិតរបស់អ្នកជាមួយនឹងការប្រតិកម្មនិងអនុសាសន៍ផ្ទាល់ខ្លួន។ វានឹងមានភ្លាមៗនេះ។`
  },
  lo: {
    firstQuestion: (jobRole: string, company: string) => 
      `ສະບາຍດີ! ຂ້ອຍແມ່ນນັກສຳພາດ AI ສຳລັບຕຳແໜ່ງ ${jobRole} ທີ່ ${company}. ຂ້ອຍຈະເຮັດການສຳພາດທີ່ຄົບຖ້ວນທີ່ຖືກອອກແບບສະເພາະສຳລັບບົດບາດ ແລະ ບໍລິສັດນີ້. ມາເລີ່ມຕົ້ນດ້ວຍການແນະນຳ - ກະລຸນາບອກຂ້ອຍກ່ຽວກັບຕົວເຈົ້າ ແລະ ເຫດຜົນທີ່ເຈົ້າສົນໃຈໃນຕຳແໜ່ງນີ້ທີ່ ${company}.`,
    followUpGeneric: "ນັ້ນໜ້າສົນໃຈ. ເຈົ້າສາມາດບອກຂ້ອຍເພີ່ມເຕີມກ່ຽວກັບສະຖານະການສະເພາະທີ່ເຈົ້າສະແດງໃຫ້ເຫັນທັກສະນັ້ນໄດ້ບໍ?",
    finalMessage: (jobRole: string, company: string) =>
      `ຂໍຂອບໃຈສຳລັບການສຳພາດທີ່ຄົບຖ້ວນນີ້! ເຈົ້າໄດ້ໃຫ້ຄວາມເຂົ້າໃຈທີ່ດີເລີດກ່ຽວກັບປະສົບການ ແລະ ວິທີການເຂົ້າຫາຂອງເຈົ້າຕໍ່ບົດບາດ ${jobRole} ທີ່ ${company}. ຂ້ອຍກຳລັງກະກຽມການປະເມີນຜົນປະສິດທິພາບລະອຽດຂອງເຈົ້າດ້ວຍຄຳຕິຊົມ ແລະ ຄຳແນະນຳສ່ວນບຸກຄົນ. ສິ່ງນີ້ຈະມີໃນໄວໆນີ້.`
  },
  'zh-sg': {
    firstQuestion: (jobRole: string, company: string) => 
      `您好！我是您的AI面试官，负责${company}的${jobRole}职位面试。我将针对此职位和公司进行全面的定制化面试。让我们从自我介绍开始 - 请告诉我您的情况以及您为什么对${company}的这个职位感兴趣。`,
    followUpGeneric: "很有趣。您能详细描述一个您展示了该技能的具体情况吗？",
    finalMessage: (jobRole: string, company: string) =>
      `感谢您参加这次全面的面试！您对${company}${jobRole}职位的经验和方法提供了出色的见解。我正在准备您的详细绩效评估，包括个性化反馈和建议。这将很快提供给您。`
  }
};

export class AIService {
  static async generateInterviewQuestion(
    session: InterviewSession,
    messages: InterviewMessage[],
    questionNumber: number
  ): Promise<string> {
    const conversationHistory = messages
      .map(msg => ({
        role: msg.messageType === 'ai' ? 'assistant' : 'user',
        content: msg.content,
        timestamp: msg.timestamp || new Date()
      }));

    const context = {
      stage: "perform-simulation",
      jobRole: session.userJobPosition || "Software Engineer",
      company: session.userCompanyName || "Technology Company",
      candidateBackground: "Experienced professional",
      keyObjectives: `Assess candidate suitability for ${session.userJobPosition} at ${session.userCompanyName}`,
      userJobPosition: session.userJobPosition || undefined,
      userCompanyName: session.userCompanyName || undefined,
    };

    const language = session.interviewLanguage || 'en';
    console.log(`Generating question in language: ${language} for session ${session.id}`);

    try {
      const persona = await sealionService.generateInterviewerPersona(context, language);
      console.log(`Successfully generated persona for ${language}`);
      
      if (questionNumber === 1 && conversationHistory.length === 0) {
        const response = await sealionService.generateFirstQuestion(context, persona, language);
        console.log(`Successfully generated first question in ${language}`);
        return typeof response === 'string' ? response : (response.content || 'Interview question generated');
      } else {
        const response = await sealionService.generateFollowUpQuestion(
          context,
          persona,
          conversationHistory,
          questionNumber,
          language
        );
        console.log(`Successfully generated follow-up question in ${language}: ${response.content?.substring(0, 50)}...`);
        return typeof response === 'string' ? response : (response.content || 'Interview question generated');
      }
    } catch (personaError) {
      console.error(`Error generating persona: ${personaError instanceof Error ? personaError.message : String(personaError)}`);
      
      // If persona fails, try direct question generation
      try {
        if (questionNumber === 1 && conversationHistory.length === 0) {
          const response = await sealionService.generateFirstQuestion(context, null, language);
          console.log(`Successfully generated first question without persona in ${language}`);
          return typeof response === 'string' ? response : (response.content || 'Interview question generated');
        } else {
          const response = await sealionService.generateFollowUpQuestion(
            context,
            null,
            conversationHistory,
            questionNumber,
            language
          );
          console.log(`Successfully generated follow-up question without persona in ${language}: ${response.content?.substring(0, 50)}...`);
          return typeof response === 'string' ? response : (response.content || 'Interview question generated');
        }
      } catch (error) {
        console.error(`Error generating ${questionNumber === 1 ? 'first' : 'follow-up'} question:`, error);
        console.log(`Using ${language} language fallback due to AWS error`);
        
        // Use language-specific fallback
        const languageFallback = LANGUAGE_FALLBACKS[language as keyof typeof LANGUAGE_FALLBACKS] || LANGUAGE_FALLBACKS.en;
        console.log(`Selected fallback for language: ${language}`, languageFallback ? 'found' : 'not found');
        
        if (questionNumber === 1 && conversationHistory.length === 0) {
          const result = languageFallback.firstQuestion(
            session.userJobPosition || "Software Engineer",
            session.userCompanyName || "Technology Company"
          );
          console.log(`Fallback first question result: ${result.substring(0, 50)}...`);
          return result;
        } else {
          // Generate contextual follow-up based on conversation and question number
          const result = this.generateContextualFollowUp(
            conversationHistory, 
            questionNumber, 
            session, 
            languageFallback, 
            language
          );
          console.log(`Contextual fallback follow-up result: ${result.substring(0, 50)}...`);
          return result;
        }
      }
    }
  }

  static async generateComprehensiveEvaluation(
    session: InterviewSession,
    messages: InterviewMessage[]
  ): Promise<Partial<AiEvaluationResult>> {
    const conversationHistory = messages
      .map(msg => ({
        role: msg.messageType === 'ai' ? 'assistant' : 'user',
        content: msg.content,
        timestamp: msg.timestamp || new Date()
      }));

    const context = {
      stage: "perform-simulation",
      jobRole: session.userJobPosition || "Software Engineer",
      company: session.userCompanyName || "Technology Company",
      candidateBackground: "Experienced professional",
      keyObjectives: `Comprehensive evaluation for ${session.userJobPosition} at ${session.userCompanyName}`,
      userJobPosition: session.userJobPosition || undefined,
      userCompanyName: session.userCompanyName || undefined,
    };

    const language = session.interviewLanguage || 'en';

    try {
      // Generate comprehensive assessment using SeaLion with new 9-criteria rubric
      const assessment = await sealionService.generateSTARAssessment(
        conversationHistory,
        context,
        language
      );

      // Extract rubric scores from SeaLion assessment
      const rubricScores = assessment.rubricScores || {};
      const weightedScore = assessment.weightedOverallScore || 3.5;
      const overallRating = assessment.overallRating || (
        weightedScore >= 3.5 ? "Pass" : 
        weightedScore >= 3.0 ? "Borderline" : "Fail"
      );
      
      // Calculate weighted overall score based on the 9-criteria weightings
      const calculateWeightedScore = (scores: any) => {
        const weights = {
          relevance: 0.15,
          starStructure: 0.15,
          specificEvidence: 0.15,
          roleAlignment: 0.15,
          outcomeOriented: 0.15,
          communication: 0.10,
          problemSolving: 0.10,
          culturalFit: 0.05,
          learningAgility: 0.05
        };
        
        const weightedSum = 
          (scores.relevanceScore || 3) * weights.relevance +
          (scores.starStructureScore || 3) * weights.starStructure +
          (scores.specificEvidenceScore || 3) * weights.specificEvidence +
          (scores.roleAlignmentScore || 3) * weights.roleAlignment +
          (scores.outcomeOrientedScore || 3) * weights.outcomeOriented +
          (scores.communicationScore || 3) * weights.communication +
          (scores.problemSolvingScore || 3) * weights.problemSolving +
          (scores.culturalFitScore || 3) * weights.culturalFit +
          (scores.learningAgilityScore || 3) * weights.learningAgility;
          
        return Number(weightedSum.toFixed(2));
      };
      
      const calculatedWeightedScore = calculateWeightedScore(rubricScores);
      
      return {
        // New 9-criteria rubric scores (1-5 scale)
        relevanceScore: (rubricScores.relevanceScore || 3).toString(),
        relevanceFeedback: rubricScores.relevanceFeedback || "Response addresses the question appropriately.",
        
        starStructureScore: (rubricScores.starStructureScore || 3).toString(),
        starStructureFeedback: rubricScores.starStructureFeedback || "Responses follow logical structure.",
        
        specificEvidenceScore: (rubricScores.specificEvidenceScore || 3).toString(),
        specificEvidenceFeedback: rubricScores.specificEvidenceFeedback || "Provides adequate examples and evidence.",
        
        roleAlignmentScore: (rubricScores.roleAlignmentScore || 3).toString(),
        roleAlignmentFeedback: rubricScores.roleAlignmentFeedback || "Experience aligns well with role requirements.",
        
        outcomeOrientedScore: (rubricScores.outcomeOrientedScore || 3).toString(),
        outcomeOrientedFeedback: rubricScores.outcomeOrientedFeedback || "Demonstrates focus on measurable outcomes.",
        
        communicationScore: (rubricScores.communicationScore || 3).toString(),
        communicationFeedback: rubricScores.communicationFeedback || "Clear and professional communication style.",
        
        problemSolvingScore: (rubricScores.problemSolvingScore || 3).toString(),
        problemSolvingFeedback: rubricScores.problemSolvingFeedback || "Shows good analytical thinking.",
        
        culturalFitScore: (rubricScores.culturalFitScore || 3).toString(),
        culturalFitFeedback: rubricScores.culturalFitFeedback || "Demonstrates good cultural alignment.",
        
        learningAgilityScore: (rubricScores.learningAgilityScore || 3).toString(),
        learningAgilityFeedback: rubricScores.learningAgilityFeedback || "Shows adaptability and learning mindset.",
        
        // Calculated weighted scores
        weightedOverallScore: calculatedWeightedScore.toString(),
        overallRating: calculatedWeightedScore >= 3.5 ? "Pass" : 
                      calculatedWeightedScore >= 3.0 ? "Borderline" : "Fail",
        
        // Legacy fields for backwards compatibility (derived from new rubric)
        empathyScore: (rubricScores.culturalFitScore || 3).toString(),
        culturalAlignmentScore: (rubricScores.culturalFitScore || 3).toString(),
        overallScore: (calculatedWeightedScore * 2).toString(), // Convert 1-5 to 1-10 scale for legacy display
        
        // Existing evaluation features
        qualitativeObservations: assessment.summary || "Comprehensive evaluation based on 9-criteria interview rubric.",
        actionableInsights: assessment.actionableInsights || [
          `Focus on demonstrating specific examples relevant to ${session.userJobPosition}`,
          `Research ${session.userCompanyName}'s recent initiatives and values`,
          "Practice articulating your problem-solving approach using the STAR method"
        ],
        personalizedDrills: [
          "Practice behavioral questions with specific metrics and outcomes",
          `Research ${session.userCompanyName}'s technical challenges and propose solutions`,
          "Conduct mock technical discussions with peers",
          "Practice explaining complex concepts in simple terms"
        ],
        reflectionPrompts: [
          `How would you adapt your experience to ${session.userCompanyName}'s unique culture?`,
          "What specific value would you bring to this role that others might not?",
          "How do you plan to grow in this position over the next 2 years?"
        ],
        badgeEarned: calculatedWeightedScore >= 4.0 ? "Interview Excellence" : 
                     calculatedWeightedScore >= 3.5 ? "Strong Candidate" : 
                     calculatedWeightedScore >= 3.0 ? "Interview Participant" : "Needs Practice",
        pointsEarned: Math.floor(calculatedWeightedScore * 20), // Scale to 0-100 points
        strengths: assessment.keyStrengths || [
          "Clear communication style",
          "Relevant experience",
          "Professional demeanor"
        ],
        improvementAreas: assessment.areasForImprovement || [
          "Provide more specific examples",
          "Ask more insightful questions",
          "Connect experience to company needs"
        ]
      };
    } catch (error) {
      console.error('Error generating comprehensive evaluation:', error);
      // Fallback evaluation with default rubric scores
      return {
        relevanceScore: "3.0",
        relevanceFeedback: "Response addresses basic question requirements.",
        starStructureScore: "3.0", 
        starStructureFeedback: "Adequate structure in responses.",
        specificEvidenceScore: "3.0",
        specificEvidenceFeedback: "Some examples provided.",
        roleAlignmentScore: "3.0",
        roleAlignmentFeedback: "Experience shows potential for the role.",
        outcomeOrientedScore: "3.0",
        outcomeOrientedFeedback: "Some focus on outcomes demonstrated.",
        communicationScore: "3.0",
        communicationFeedback: "Clear and understandable communication.",
        problemSolvingScore: "3.0", 
        problemSolvingFeedback: "Basic problem-solving approach shown.",
        culturalFitScore: "3.0",
        culturalFitFeedback: "Adequate cultural alignment.",
        learningAgilityScore: "3.0",
        learningAgilityFeedback: "Shows willingness to learn.",
        weightedOverallScore: "3.0",
        overallRating: "Borderline",
        overallScore: "6.0",
        empathyScore: "3.0",
        culturalAlignmentScore: "3.0",
        qualitativeObservations: "Interview completed successfully. Detailed evaluation processing encountered an issue.",
        actionableInsights: ["Continue practicing interview skills", "Research company-specific information"],
        personalizedDrills: ["Practice behavioral questions", "Prepare technical examples"],
        reflectionPrompts: ["How did you feel about this interview?", "What would you do differently?"],
        badgeEarned: "Interview Participant",
        pointsEarned: 60,
        strengths: ["Engaged in the conversation", "Completed the interview"],
        improvementAreas: ["Continue practicing", "Prepare more examples"]
      };
    }
  }

  static async shouldCompleteInterview(messageCount: number): Promise<boolean> {
    // Complete after 8-12 questions depending on conversation flow
    return messageCount >= 16; // 8 Q&A pairs
  }

  // Generate more contextual follow-up questions based on conversation flow
  private static generateContextualFollowUp(
    conversationHistory: Array<{ role: string; content: string; timestamp: Date }>,
    questionNumber: number,
    session: any,
    languageFallback: any,
    language: string
  ): string {
    const lastUserResponse = conversationHistory
      .filter(msg => msg.role === 'user')
      .pop()?.content?.toLowerCase() || '';

    // Define contextual follow-up templates by language and question progression
    const contextualTemplates = {
      'zh-sg': {
        3: [
          '让我们换个角度。您认为在这个职位上最大的挑战是什么？',
          '非常好。您能分享一个您解决复杂问题的经历吗？',
          '了解了。您如何看待团队合作在这个角色中的重要性？'
        ],
        4: [
          '您对我们公司有什么了解？为什么想加入我们？',
          '描述一下您理想的工作环境是什么样的？',
          '您在前一份工作中最大的成就是什么？'
        ],
        5: [
          '如果遇到意见分歧，您通常如何处理？',
          '您如何保持对行业发展的关注和学习？',
          '描述一次您必须在压力下做决定的经历。'
        ]
      },
      'id': {
        3: [
          'Mari kita ubah sudut pandang. Menurut Anda, tantangan terbesar dalam posisi ini apa?',
          'Bagus sekali. Bisakah Anda berbagi pengalaman menyelesaikan masalah kompleks?',
          'Saya paham. Bagaimana Anda melihat pentingnya kerja tim dalam peran ini?'
        ],
        4: [
          'Apa yang Anda ketahui tentang perusahaan kami? Mengapa ingin bergabung?',
          'Ceritakan tentang lingkungan kerja ideal menurut Anda?',
          'Apa pencapaian terbesar Anda di pekerjaan sebelumnya?'
        ],
        5: [
          'Jika ada perbedaan pendapat, biasanya Anda menanganinya bagaimana?',
          'Bagaimana cara Anda mengikuti perkembangan industri dan terus belajar?',
          'Ceritakan saat Anda harus membuat keputusan di bawah tekanan.'
        ]
      },
      'th': {
        3: [
          'มาเปลี่ยนมุมมองกันหน่อย คุณคิดว่าความท้าทายที่ใหญ่ที่สุดในตำแหน่งนี้คืออะไร?',
          'ดีมาก คุณช่วยแบ่งปันประสบการณ์การแก้ปัญหาที่ซับซ้อนได้ไหม?',
          'เข้าใจแล้ว คุณมองเห็นความสำคัญของการทำงานเป็นทีมในบทบาทนี้อย่างไร?'
        ],
        4: [
          'คุณรู้อะไรเกี่ยวกับบริษัทเราบ้าง? ทำไมถึงอยากเข้าร่วม?',
          'บรรยากาศการทำงานในอุดมคติของคุณเป็นอย่างไร?',
          'ความสำเร็จที่ยิ่งใหญ่ที่สุดในงานก่อนหน้าคืออะไร?'
        ],
        5: [
          'หากมีความเห็นไม่ตรงกัน คุณมักจะจัดการอย่างไร?',
          'คุณติดตามการพัฒนาของอุตสาหกรรมและเรียนรู้อย่างต่อเนื่องอย่างไร?',
          'เล่าเหตุการณ์ที่คุณต้องตัดสินใจภายใต้ความกดดัน'
        ]
      },
      'ms': {
        3: [
          'Mari tukar perspektif. Pada pendapat anda, apakah cabaran terbesar dalam jawatan ini?',
          'Bagus sekali. Bolehkah anda kongsi pengalaman menyelesaikan masalah kompleks?',
          'Saya faham. Bagaimana anda melihat kepentingan kerja berpasukan dalam peranan ini?'
        ],
        4: [
          'Apa yang anda tahu tentang syarikat kami? Mengapa ingin menyertai kami?',
          'Ceritakan tentang persekitaran kerja ideal menurut anda?',
          'Apakah pencapaian terbesar anda dalam kerja sebelum ini?'
        ],
        5: [
          'Jika ada perbezaan pendapat, biasanya anda mengendalikannya bagaimana?',
          'Bagaimana cara anda mengikuti perkembangan industri dan terus belajar?',
          'Ceritakan masa anda terpaksa membuat keputusan di bawah tekanan.'
        ]
      }
    };

    // Get available templates for this language and question number
    const langTemplates = contextualTemplates[language as keyof typeof contextualTemplates];
    const questionTemplates = langTemplates?.[questionNumber as keyof typeof langTemplates];

    if (questionTemplates && questionTemplates.length > 0) {
      // Select different template based on question number to avoid repetition
      const templateIndex = (questionNumber - 3) % questionTemplates.length;
      return questionTemplates[templateIndex];
    }

    // Fallback to generic if no specific template
    return languageFallback.followUpGeneric;
  }
}