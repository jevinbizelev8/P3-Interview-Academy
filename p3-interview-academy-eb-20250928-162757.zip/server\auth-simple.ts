import bcrypt from "bcryptjs";
import session from "express-session";
import crypto from "crypto";
import type { Express, RequestHandler } from "express";
import { createSessionStore } from "./session-store";
import { storage } from "./storage";

export function getSession() {
  const sessionTtlMs = 7 * 24 * 60 * 60 * 1000; // 1 week
  const sessionStore = createSessionStore({
    ttl: Math.floor(sessionTtlMs / 1000),
  });

  // Let Express inspect X-Forwarded-Proto and auto-set secure cookies when appropriate
  const secureCookie = process.env.FORCE_HTTPS === 'true' ? true : 'auto';
  const sameSite = secureCookie === true ? 'none' : 'lax';

  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    name: 'connect.sid',
    rolling: true, // Reset expiration on each request for active users
    cookie: {
      httpOnly: true, // Prevent XSS attacks
      secure: secureCookie,
      maxAge: sessionTtlMs, // 7 days but resets with rolling
      sameSite,
      domain: undefined, // Let browser handle domain
    },
    // Enhanced security: clean up expired sessions
    genid: () => {
      return crypto.randomBytes(32).toString('hex');
    }
  });
}


export async function setupSimpleAuth(app: Express) {
  app.set("trust proxy", 1);
  
  // Add session middleware
  const sessionMiddleware = getSession();
  app.use(sessionMiddleware);

  // Signup endpoint
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { email, password, firstName, lastName } = req.body;
      
      if (!email || !password || !firstName) {
        return res.status(400).json({ message: "Email, password, and first name are required" });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }

      // Hash password
      const saltRounds = 12;
      const hashedPassword = await bcrypt.hash(password, saltRounds);

      // Create user
      const userId = `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const user = await storage.upsertUser({
        id: userId,
        email,
        firstName,
        lastName: lastName || "",
        role: "user",
        passwordHash: hashedPassword
      });

      // Create session
      (req.session as any).userId = user.id;
      (req.session as any).userEmail = user.email;
      
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ message: "Registration failed" });
        }
        
        console.log("Signup session saved successfully, ID:", req.sessionID);
        
        res.json({ 
          success: true, 
          user: { 
            id: user.id, 
            email: user.email, 
            firstName: user.firstName, 
            lastName: user.lastName 
          } 
        });
      });
    } catch (error) {
      console.error("Signup error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Login endpoint
  app.post("/api/auth/login", async (req, res) => {
    console.log("🔐 LOGIN ATTEMPT:", {
      email: req.body?.email,
      hasPassword: !!req.body?.password,
      userAgent: req.get('User-Agent'),
      origin: req.get('Origin'),
      sessionID: req.sessionID
    });
    
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        console.log("❌ LOGIN FAILED: Missing credentials");
        return res.status(400).json({ message: "Email and password are required" });
      }

      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user || !user.passwordHash) {
        console.log("❌ LOGIN FAILED: User not found or no password hash:", { email, userExists: !!user, hasPasswordHash: !!user?.passwordHash });
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Verify password
      const passwordValid = await bcrypt.compare(password, user.passwordHash);
      if (!passwordValid) {
        console.log("❌ LOGIN FAILED: Invalid password for user:", user.id);
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Create session
      console.log("✅ LOGIN SUCCESS: Creating session for user:", {
        userId: user.id,
        email: user.email,
        sessionID: req.sessionID,
        cookieSettings: {
          secure: process.env.NODE_ENV === 'production',
          httpOnly: true,
          sameSite: 'lax'
        }
      });
      
      (req.session as any).userId = user.id;
      (req.session as any).userEmail = user.email;
      
      req.session.save((err) => {
        if (err) {
          console.error("❌ SESSION SAVE ERROR:", err);
          return res.status(500).json({ message: "Login failed" });
        }
        
        console.log("✅ SESSION SAVED:", {
          sessionID: req.sessionID,
          userId: (req.session as any).userId,
          cookieWillBeSet: true,
          sessionData: {
            userId: (req.session as any).userId,
            userEmail: (req.session as any).userEmail
          }
        });
        
        res.json({ 
          success: true, 
          user: { 
            id: user.id, 
            email: user.email, 
            firstName: user.firstName, 
            lastName: user.lastName 
          } 
        });
      });
    } catch (error) {
      console.error("❌ LOGIN ERROR:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Get current user
  app.get("/api/auth/user", async (req, res) => {
    const authStartTime = Date.now();
    console.log("🔍 AUTH CHECK:", {
      sessionID: req.sessionID,
      cookies: req.headers.cookie,
      userAgent: req.get('User-Agent'),
      origin: req.get('Origin'),
      referer: req.get('Referer')
    });
    
    try {
      const session = req.session as any;
      const sessionLoadTime = Date.now() - authStartTime;
      
      console.log("📋 SESSION STATE:", {
        exists: !!req.session,
        sessionID: req.sessionID,
        userId: session?.userId,
        userEmail: session?.userEmail,
        sessionKeys: session ? Object.keys(session) : 'no session',
        loadTime: `${sessionLoadTime}ms`
      });
      
      if (!session.userId) {
        console.log(`❌ AUTH FAILED: No userId in session (checked in ${Date.now() - authStartTime}ms)`);
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userLookupStart = Date.now();
      const user = await storage.getUser(session.userId);
      const userLookupTime = Date.now() - userLookupStart;
      if (!user) {
        console.log("❌ AUTH FAILED: User not found in database:", session.userId);
        return res.status(401).json({ message: "User not found" });
      }

      console.log("✅ AUTH SUCCESS: User authenticated:", {
        userId: user.id,
        email: user.email,
        sessionID: req.sessionID,
        totalTime: `${Date.now() - authStartTime}ms`,
        userLookupTime: `${userLookupTime}ms`
      });

      res.json({
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      });
    } catch (error) {
      console.error("❌ AUTH ERROR:", error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Logout endpoint
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ success: true });
    });
  });

  // Forgot password endpoint (simplified version without email sending)
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      // Check if user exists
      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Don't reveal if email exists for security
        return res.json({ success: true, message: "If the email exists, reset instructions have been sent" });
      }

      // In a real app, you would:
      // 1. Generate a secure reset token
      // 2. Store it in database with expiration
      // 3. Send email with reset link
      
      // For now, just simulate success
      console.log(`Password reset requested for: ${email}`);
      console.log(`In a real app, would send email with reset link`);
      
      res.json({ 
        success: true, 
        message: "If the email exists, reset instructions have been sent" 
      });
    } catch (error) {
      console.error("Forgot password error:", error);
      res.status(500).json({ message: "Failed to process password reset request" });
    }
  });

  // Reset password endpoint (simplified version)
  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, newPassword } = req.body;
      
      if (!token || !newPassword) {
        return res.status(400).json({ message: "Token and new password are required" });
      }

      // In a real app, you would:
      // 1. Validate the reset token
      // 2. Check if it's not expired
      // 3. Find the user associated with the token
      // 4. Update their password
      
      // For now, just simulate success
      console.log(`Password reset with token: ${token}`);
      
      res.json({ 
        success: true, 
        message: "Password has been reset successfully" 
      });
    } catch (error) {
      console.error("Reset password error:", error);
      res.status(500).json({ message: "Failed to reset password" });
    }
  });
}

export const requireAuth: RequestHandler = async (req, res, next) => {
  const session = req.session as any;
  if (!session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const user = await storage.getUser(session.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    req.user = {
      id: user.id,
      email: user.email || undefined,
      firstName: user.firstName || undefined,
      lastName: user.lastName || undefined,
      role: user.role || "user"
    };
    next();
  } catch (error) {
    console.error("Auth middleware error:", error);
    res.status(500).json({ message: "Authentication failed" });
  }
};
